# AdvPrint Pro — Hub HTTP API

Base URL: `http://127.0.0.1:9235` (default)
Auth: header `X-AdvPrint-Token: <token>` (fresh installs: a private random token - read it with `python advprint.py token`; legacy `X-PrintHub-Token` header accepted), or `?token=` query on GET navigation, or `"token"` JSON field.
All responses are JSON with an `"ok"` field. The API is CORS-open; `Access-Control-Allow-Private-Network` is answered only to origins on the `allowed_origins` list (v2.9.1).

**v3.0.0 security rules** (independent-audit hardening, introduced in v2.9.1):
- Requests whose `Host` header is not this hub's own name/loopback/LAN IP get `421`.
- `POST /ipp/print` refuses browser `Origin` requests (`403`) - native IPP clients only.
- POST bodies larger than 1 MB are refused (`401`) before reading unless the request carries the token (header or `?token=`). Keep sending the QR-link token on `/send` uploads - that still works.
- `page_url` and every `pdf_url` redirect hop run the private-address guard (`400` on file:// / internal hosts).
- `?limit=` on `/jobs` and `/audit` is clamped (1-200 / 1-1000).

**v3.2.6 UI SECURITY GATE - the console is local-only:**
- Every UI / settings / management endpoint answers **only on the hub
  PC itself** (loopback OR one of the machine's own IPs): `/ui`,
  `/dashboard`, `/docs`, `/`, `/config` (POST), `/token/*`,
  `/autostart`, `/queue/*` control, `/history/clear`,
  `/jobs/release_all`, `/tool`, `/restart`, `/printers/set-default`,
  `/extension/policy/*`, `/firewall/*`, `/livetest`, `/qr`, `/stats`,
  `/audit`, `/export/*`, `/debug`, `/diagnostics`, `/peers`,
  `/dropzone`, `/lan/selftest`. A non-local caller gets a branded
  `403` (HTML page for browsers, JSON for API clients) that points at
  the print URLs; the attempt is audited (`ui.locked`).
- The **print surface stays open** to every address the Allowed-IPs
  list admits (default `*`): `POST /print`, `GET+POST /send`,
  `GET+POST /ipp/*` (+ the 631 mirror, RAW 9100), `GET /jobs`,
  `POST /jobs/<id>/cancel`, `POST /jobs/<id>/print-now`,
  `POST /jobs/bulk-reprint`, `GET /printers`, `GET /health`,
  `GET /extension/*`, `GET /connect`, `GET /testprint`,
  `POST /client/report`, `POST /debug/report`.
- The two gates stack: Allowed-IPs (v3.2.3) decides who may talk to
  the hub AT ALL; the v3.2.6 gate then restricts non-local callers to
  the print surface. The hub PC itself always passes both.

---

## POST /ipp/print — IPP network printer endpoint *(v2.9.0, no token)*

The hub is a real IPP printer. Binary IPP/1.1 bodies only (this is what
Windows / phone print services send - do not call it by hand unless you
speak IPP):

- `Get-Printer-Attributes (0x000B)` → printer-state, make-and-model
  `AdvPrint Pro <version> (virtual)`, document formats
  `application/pdf`, `image/jpeg`, `application/octet-stream`.
- `Print-Job (0x0002)` → routes the document by content:
  `%PDF` → the normal PDF pipeline (queue, History, audit, reprint);
  JPEG → single-page PDF (DCTDecode); PostScript / PCL / ESC/POS / ZPL
  → RAW passthrough to the selected printer. Answers `successful-ok`
  with `job-id` / `job-state`, or
  `client-error-document-format-not-supported`.
- `Validate-Job (0x0004)` → `successful-ok`.
- Anything else → `server-error-operation-not-supported (0x040F)`;
  unparseable body → `client-error-bad-request (0x0400)`.

The printer URL for the "Add a printer" dialogs is
`http://<lan-ip>:9235/ipp/print` (shown on the dashboard LAN card with
a QR: `GET /qr?kind=ipp`). IPP needs no token - it is a printer
protocol - but it only accepts print data, is bounded by the same size
limit as uploads, every job is audited with the source IP, and it can
be turned off with `"ipp_printer": false` (config.json or
`POST /config`). Browsers opening the URL with GET get a how-to page.

### RAW JetDirect printer port - TCP 9100 *(v2.9.0, no token)*

While LAN sharing is ON, the hub also listens on TCP 9100 (config
`raw_printer_port`, 0 = off) and speaks plain JetDirect: open a socket,
stream the bytes, close. Windows "Add a printer using TCP/IP address"
(device type *Generic Network Card*) and label/receipt apps use this.
Payload routing is the same as IPP. The listener binds the PC's LAN IP
(never 0.0.0.0), follows `share_lan`, rebinds on DHCP changes and stops
when LAN sharing is turned off.

### Print destination - default / selected / IP printer *(v2.9.0)*

The hub routes every job (local API, extension, send portal, IPP, RAW)
to the configured destination - ANY printer:

| key | meaning |
| --- | --- |
| `dest_mode` | `"default"` = OS default printer &middot; `"selected"` = the printer named in `printer` &middot; `"ip"` = forward to the upstream IP printer &middot; `""` = legacy auto (selected when `printer` is set, else default) |
| `ip_printer_host` | upstream network printer IP / hostname |
| `ip_printer_port` | 0 = protocol default (RAW 9100 / IPP 631) |
| `ip_printer_proto` | `"raw"` (JetDirect: stream the bytes) or `"ipp"` (IPP 1.1 Print-Job to `/ipp/print`, `application/pdf`, `copies` supported) |

- A per-job `printer` name (body/query of `/print`, extension,
  printer groups) always wins and is always local.
- The queue honours the destination: with `dest_mode:"ip"` the hold
  check probes the IP printer's TCP reachability (the job is HELD with
  "IP printer x.x.x.x:9100 is unreachable" while it is down), the
  virtual-PDF-printer save path is skipped, and the instant
  (queue-off) path routes the same way.
- `POST /ip-printer/test` *(token)* - body `{"host": "192.168.1.50",
  "port": 0, "proto": "raw"}` (port/proto optional - falls back to the
  saved config) &rarr; `{"ok": true, "state": "ready", "ms": 12,
  "target": "192.168.1.50:9100 (raw)"}`. Test BEFORE saving - the
  dashboard "Print destination" card has the same button.
- `/health` adds `dest_mode`, `selected_printer`, `dest_display`,
  `ip_printer` and the derived **`ip_printer_mode`** flag (LAN sharing
  ON + IPP/RAW listener = this PC is addable as a network printer by
  any PC or phone, and every job prints to the chosen destination).

---

## GET /health *(no token)*

```json
{
  "ok": true,
  "app": "AdvPrint Pro",
  "version": "1.0.0",
  "os": "windows",
  "default_printer": "HP LaserJet Pro",
  "sumatra_found": true,
  "browser_found": true,
  "paused": false,
  "pending": 0,
  "jobs_today": 12,
  "token_set": true
}
```

---

## GET /printers

```json
{ "ok": true,
  "printers": [ {"name": "HP LaserJet Pro", "is_default": true},
                {"name": "XP-80C Thermal", "is_default": false} ],
  "default": "HP LaserJet Pro" }
```

---

## POST /printers/set-default (v3.2.5)

**Actually sets the OS default printer** (the v3.2.4-and-older "Set
Default" button only saved the hub config key - Windows kept its own
default and the "let Windows manage my default printer" feature flipped
it back). Body: `{"printer": "<name>"}` (`default_printer` also
accepted).

Windows: disables the auto-manage feature first
(`HKCU\...\Windows\LegacyDefaultPrinterMode = 1`, per-user, no UAC),
then `WScript.Network.SetDefaultPrinter`, then reads the default back
and only reports success when it verifies. Unix: `lpoptions -d <name>`.
The hub destination key (`printer`) stays in sync; every call is
audit-logged (`printers.set_default`).

```json
// 200 - verified
{ "ok": true, "default": "HP LaserJet Pro", "printer": "HP LaserJet Pro",
  "detail": "Windows default printer is now 'HP LaserJet Pro' (auto-manage disabled: LegacyDefaultPrinterMode=1)" }
// 200 - honest failure (unknown printer, OS refused)
{ "ok": false, "default": "…", "error": "lpoptions: Unknown destination X" }
```

---

## POST /autostart (v3.2.5 - the REAL state)

`{"enabled": true|false}` writes/removes the logon autostart entry
(Windows: `shell:startup\AdvPrint Pro.lnk` - the same shortcut the tray
icon and Task Manager → Startup apps show; Linux: XDG
`~/.config/autostart/advprint-pro.desktop`). Response:
`{"ok":true,"enabled":<real state>,"path":"…"}`. The health snapshot is
rebuilt immediately, so `/health` → `"autostart": true|false` always
mirrors the real file state (this is what the console Settings switch
now reads and writes).

---

## POST /print

One of the payload sources is required. Common optional fields: `title`, `printer` (empty = default), `copies` (1–50), `source` (free tag shown in history), `destination` (`"printer"` default or `"file"` to save as PDF without printing).

| Source field | Meaning | Notes |
|---|---|---|
| `raw_base64` | pre-built ESC/POS/ZPL/PCL bytes | becomes a `raw` job (winspool RAW / `lp -o raw`) |
| `text` + `lang: escpos\|zpl` | raw receipt/label printing | `zpl` = verbatim `^XA…^XZ` (latin-1); `escpos` = marker builder |
| `pdf_base64` | Raw PDF bytes, base64 | Must start with `%PDF-` |
| `pdf_url` | Download a PDF | Max 25 MB, must be a real PDF, private-address guard |
| `image_base64` | JPEG bytes, base64 | Wrapped to PDF (`paper: a4|thermal`, `landscape`) |
| `html` | HTML string | Rendered by headless Chrome/Edge (max 2 concurrent) |
| `page_url` | URL of a page | Rendered by headless Chrome/Edge, private-address guard |
| `text` | Plain text | `paper:"thermal"` → 80 mm roll; `paper:"a4"` → A4. Markers: `#big `, `|center| ` |

**Every print option** (works in JSON, on the query string, and in
`window.advprint.print()` — the full annotated reference with worked
examples lives in [`DEVELOPER-API.md`](DEVELOPER-API.md)):

| Option | Values | Default |
|---|---|---|
| `priority` | 1 (urgent) … 9 (low) — the FIFO prints 1 first | 5 |
| `pages` | `"1-3,5"` · `odd` · `even` | all |
| `per_sheet` | 1 2 4 6 9 16 (n-up, CUPS) | 1 |
| `quality` | `draft` `normal` `high` · `"600"` · `"600dpi"` | driver |
| `dpi` | 72–2400 (wins over `quality`) | — |
| `scale_pct` / `margin_mm` | 25–400 % / mm (html+text renders) | — |
| `duplex` | `simplex` `duplex` `duplexlong` `duplexshort` | driver |
| `paper_size` / `orientation` / `tray` | A4… / landscape / CUPS tray | driver |
| `profile` | named hub print profile (paper/tray/duplex/copies/printer) | — |
| `queue` | `false` = instant print in its own thread (parallel; offline printer → auto-queued) | `true` |
| `run_at` | ISO datetime or `+Ns/+Nm/+Nh/+Nd` | now |
| `dedupe` | `false` allows identical repeats inside the window | `true` (5 min) |
| `reason` / `watermark` / `watermark_text` | audit reason / PDF stamp + text (max 24, default `REPRINT`) | — |

```bash
curl -X POST http://127.0.0.1:9235/print \
  -H "X-AdvPrint-Token: $TOKEN" -H "Content-Type: application/json" \
  -d '{"pdf_base64":"JVBERi0...","title":"Invoice 42","printer":"HP LaserJet Pro","copies":2}'
```

Response: `{"ok": true, "job_id": 17, "kind": "a4", "copies": 2, "destination": "printer", "message": "queued to printer"}`

### Raw binary PDF — no base64 (fastest path)

POST the PDF bytes **directly** with `Content-Type: application/pdf` — no base64 encode, no JSON, no +33% size overhead. Parameters ride the **query string** (`title`, `printer`, `copies`, `destination`, `paper`, `token` also accepted as query param).

```bash
curl -X POST "http://127.0.0.1:9235/print?title=Lab%20report&copies=1" \
  -H "X-AdvPrint-Token: $TOKEN" \
  -H "Content-Type: application/pdf" \
  --data-binary @report.pdf
```

**Laravel (mPDF, zero encoding):**

```php
Http::withHeaders(['X-AdvPrint-Token' => '$TOKEN'])
    ->withBody($pdf->output(), 'application/pdf')
    ->post('http://127.0.0.1:9235/print?title=' . urlencode('Lab report 197253'));
```

**Laravel multipart (`Http::attach`)** — file field `pdf`/`file`, text fields become parameters:

```php
Http::withHeaders(['X-AdvPrint-Token' => '$TOKEN'])
    ->attach('pdf', $pdf->output(), 'report.pdf')
    ->post('http://127.0.0.1:9235/print', ['title' => 'Lab report 197253']);
```

**No bytes at all — `pdf_url`:** the hub downloads the PDF itself (max 25 MB). For login-protected Laravel routes use a signed URL: `URL::temporarySignedRoute('reports.pdf', now()->addMinutes(5), [...])`.

Raw limits: max 25 MB, body must start with `%PDF-`; anything else → `400`.

### Destination "file" — save as PDF, no paper

Add `"destination": "file"` (or set `printer` to the extension alias `"__file__"`) and the hub **saves the rendered PDF into a folder instead of printing** — no dialog, no paper, no queue. Default folder: `~/Downloads/AdvPrint` (override with `ADVPRINT_FILE_DIR`).

```bash
curl -X POST http://127.0.0.1:9235/print \
  -H "X-AdvPrint-Token: $TOKEN" -H "Content-Type: application/json" \
  -d '{"text":"Daily summary","paper":"a4","title":"summary","destination":"file"}'
```

Response: `{"ok": true, "job_id": 18, "kind": "a4", "destination": "file", "status": "saved", "file": "/home/me/Downloads/AdvPrint/summary-20240101-120000.pdf", "url_path": "/jobs/18/file", "message": "saved as PDF file - no paper used"}`

The job appears in history with status `saved`; download it any time via `GET /jobs/18/file`, or print it later with `POST /jobs/18/reprint` (goes to the OS default printer).

Errors: `400` bad payload · `401` bad token · `500` render failure (html/page).

---

## Queue control

| Endpoint | Effect |
|---|---|
| `GET /queue` | `{"ok":true,"paused":false,"pending":2,"current":{...job...}}` |
| `POST /queue/pause` | Worker stops taking jobs (already-running job finishes) |
| `POST /queue/resume` | Worker continues; queued jobs print in FIFO order |
| `POST /queue/clear` | **v3.2.6** Cancels every live job (queued/held/scheduled/printing) AND removes all terminal rows - the queue and history come back empty. With `{"finished": true}` it deletes finished rows only (alias of `/history/clear`). **Local-only** (see the security gate) |

The queue is **DB-driven** (SQLite): pending jobs survive hub restarts, and jobs stuck in `printing` after a crash are re-queued at startup.

---

## Jobs & history

| Endpoint | Meaning |
|---|---|
| `GET /jobs?limit=100` | Last N jobs (newest first). Statuses: `queued printing printed saved failed canceled` |
| `GET /jobs/{id}/file` | Download the original PDF of a job |
| `POST /jobs/{id}/reprint` | Queue an exact copy of the job |
| `POST /jobs/{id}/cancel` | Cancel a queued job; if it is printing, the print process is killed |
| `GET /dropzone` | **v2.8.0** DropZone status (enabled, folder, waiting/done counts) |
| `POST /dropzone/open` | **v2.8.0** Open the DropZone folder on the hub PC (loopback only) |
| `GET /send` | **v2.8.0** The send portal page (upload a PDF from any device; token required) |
| `POST /send` | **v2.8.0** Upload + print a PDF (`multipart -F file=@x.pdf`, `application/pdf` body, or JSON `pdf_base64`) |
| `GET /qr` | **v2.8.1** QR code as SVG (`kind=send` = phone upload URL, `kind=invite` = PC invite link, `kind=ipp` = v2.9 printer URL; token required) |
| `GET /connect` | **v2.8.1** One-click invite landing page (`?t=<hub-token>&n=<PC-name>`; validates its own token) |
| `POST /peer-connect` | **v2.8.1** Auto-add a LAN peer from an invite (loopback + Origin-validated form POST; no token by design) |
| `GET /lan/selftest` | **v2.8.2** Server-side LAN check: the hub connects to its own LAN URL and reports PASS/FAIL with the reason (token required) |
| `POST /firewall/allow` | **v2.8.2** One-click Windows firewall rule for the hub port (loopback-only; triggers one UAC prompt) |
| `GET /lan/selftest` | **v2.8.2** Server-side LAN check: the hub connects to its own LAN URL and reports PASS/FAIL with the reason (token required) |
| `POST /firewall/allow` | **v2.8.2** One-click Windows firewall rule for the hub port (loopback-only; triggers one UAC prompt) |
| `POST /config` (share_lan) | **v2.8.2** now applies LIVE - the response carries `"lan":{"rebound":true,"lan_error":null}` once the LAN listener is already serving |
| `POST /config` (share_lan) | **v2.8.2** now applies LIVE - the response carries `"lan":{"rebound":true,"lan_error":null}` once the LAN listener is already serving |
| `POST /restart` | **v2.8.0** Restart the hub cleanly (it relaunches itself; queued jobs are kept) |
| `POST /jobs/bulk-reprint` | **v2.7.0** Reprint many jobs in one call |
| `POST /history/clear` | **v2.7.0** Delete every FINISHED job from the history (waiting jobs untouched). **Local-only** (see the security gate) |

### POST /send (v2.8.0) - print WITHOUT the extension
```bash
curl -X POST -H "X-AdvPrint-Token: $TOKEN" -F "file=@report.pdf" \
     "http://127.0.0.1:9235/send?title=Lab report"
# or raw body:
curl -X POST -H "X-AdvPrint-Token: $TOKEN" -H "Content-Type: application/pdf" \
     --data-binary @report.pdf "http://127.0.0.1:9235/send"
```
Accepts multipart (`file`/`pdf` field), a raw `application/pdf` body or JSON
`{"pdf_base64": "..."}`. Only real PDFs are accepted (25 MB cap). The job is
queued on the hub's printers exactly like any other job - `source: "send"`.

### GET /dropzone + POST /dropzone/open (v2.8.0)
`GET` returns `{"ok":true,"enabled":true,"dir":"...","waiting":0,"done":2,
"delete":false,"custom_dir":"","is_default":true}`. Change the settings with
`POST /config {"drop_enabled":true,"drop_dir":"C:\\Drop","drop_delete":false}`.
Every PDF that lands in the watched folder is printed and moved to `done\`
(or deleted when `drop_delete` is true) - this is the "MS Word style"
print path for apps without the extension.

### POST /restart (v2.8.0)
The hub relaunches ITSELF as a new process (the new process waits for the
old listener to release the port). Queued jobs, settings and history are
kept. The tray menu (Restart hub), AdvPrint Tool [14] and the dashboard
button all use this endpoint.

### GET /qr (v2.8.1) - QR code as SVG
```bash
curl -H "X-AdvPrint-Token: $TOKEN" \
     "http://127.0.0.1:9235/qr?kind=send" -o send-qr.svg
```
`kind=ipp` (v2.9.0) encodes the IPP printer URL
`http://<lan-ip>:9235/ipp/print` for the other PC's "Add a printer" dialog.
`kind=send` (default) encodes `http://<lan-ip>:9235/send?token=...` so any
phone on the Wi-Fi can scan it and upload a PDF through the Send portal;
`kind=invite` encodes `http://<lan-ip>:9235/connect?t=...&n=<hostname>` for
the one-click PC invite. The QR is generated by a pure-stdlib encoder
embedded in the hub (verified bit-exact against an independent
implementation) - no internet access is ever made. Answer is
`image/svg+xml` with `Cache-Control: no-store`.

### GET /connect + POST /peer-connect (v2.8.1) - one-click LAN invite
The hub PC's dashboard LAN card offers **Copy invite link**
(`http://<ip>:9235/connect?t=<hub-token>&n=<PC-name>`). Opened on the
OTHER PC, `/connect` serves a confirmation page; its button form-POSTs
to the OTHER PC's own hub at `http://127.0.0.1:9235/peer-connect` with
`url`, `token`, `name`, `confirm=1`. The receiving hub saves the peer
into `config.json` (`peer_hubs`, dedupe by URL), health-probes it and
replies with a success page.

Guards on `/peer-connect` (it works WITHOUT the receiving hub's token by
design): loopback requests only; a browser `Origin` header, when present,
must equal the peer URL being added (blocks drive-by CSRF); the peer URL
must be a private-LAN http(s) address; GET never mutates anything. Audit:
`peer.invite` / `peer.connected` / `peer.connect.denied`.

### POST /jobs/bulk-reprint (v2.7.0)

Body: either `{"ids":[12,13,14]}` (History tab "Reprint selected") or
`{"scope":"not_printed","limit":500}` (every `failed` / `dead` /
`canceled` job — "Reprint all non-printed"). Optional `reason`,
`watermark`, `watermark_text`, `printer` ride along exactly like the
single-job reprint. Per-job problems never abort the batch:

```json
{"ok":true,"queued":2,"skipped":1,
 "results":[{"id":12,"ok":true,"job_id":41},
            {"id":13,"ok":false,"error":"original file no longer stored"}]}
```

### POST /history/clear (v2.7.0)

Deletes every FINISHED job (`printed / failed / dead / canceled /
forwarded / saved`). Waiting jobs (`queued / printing / held /
scheduled`) are NEVER touched — clearing the history can not cancel a
real print. Audited as `history.cleared`.

```json
{"ok":true,"deleted":37,"message":"37 finished job(s) removed from the history"}
```

---

## GET /testprint?kind=a4|thermal

Queue a built-in test page/receipt. No body needed.

---

## CLI equivalents

```
python hub/advprint.py serve          # start (default command)
python hub/advprint.py testprint a4   # test page
python hub/advprint.py printers       # list printers
python hub/advprint.py history 20     # last 20 jobs
python hub/advprint.py reprint 17     # reprint job 17
python hub/advprint.py queue          # paused? pending? current?
python hub/advprint.py doctor         # environment self-check
```

## Browser fallback form

Strict CSP environments can POST `application/x-www-form-urlencoded` with a single field `payload` containing the JSON — same endpoints, same responses.

---

## v2.4.0 — debug, instant print, held jobs

### GET /debug?token=...
Full diagnostics — answers "why is it not printing?" in one JSON:
`version`, `uptime_s`, `worker_alive`, `paused`, `hold_offline`,
`instant_auto_queue`, `token` (masked), `printers[]` (name+status),
`default_printer`, `sumatra_found`, `sumatra_path`,
`sumatra_searched[]` (every path checked, when not found), `db`
(by_status, queue_size, success_rate, printed_7d, failed_7d),
`recent_jobs[]`, `problems[]` (level/check/message/fix),
`client_reports[]` (browser-side errors, when debug is on).

### GET /dashboard?token=...
The LIVE debug & test tool (HTML, open in a browser): send a real test
print to any printer, watch every status change live, final verdict
REAL PRINTER HIT / saved / held / failed (+fix). Release held jobs,
pause/resume, settings toggles.

### GET /audit?token=...[&limit=100]
Audit trail (SQLite, survives restarts). Events: `print.submitted`
(actor/site/ip/doc_hash), `print.held`, `print.requeued`, `print.saved`,
`auth.failed` (attempt counter), `config.changed`, `queue.paused`,
`queue.resumed`.

### GET /config?token=... · POST /config
Live settings, persisted to `<data dir>/config.json`.
POST body (header auth as usual): `{"debug":true, "hold_offline":true,
"instant_auto_queue":true, "sumatra_path":"C:\\...\\SumatraPDF.exe",
"file_dir":"D:\\pdfs", "printer":"", "token_header_only":true}`.
Response: `{"ok":true,"changed":["debug"]}`. Every change is audit-logged.

### POST /client/report
Browser-side error reports (extension sends them when Debug is on).
Body: `{"level":"error","message":"...","url":"https://..."}`.
Shown in `/debug` → `client_reports[]` and the dashboard.

### Instant / direct print
`POST /print` accepts `instant:true` or `mode:"instant"` — the job jumps
the queue (priority dispatch). If no printer is ready it auto-falls back
to the normal queue (`instant_auto_queue`), response then contains
`"auto_queued": true`. The job is never lost.

### Held jobs (hold_offline)
Jobs for an offline printer are parked as `held` with `held_reason`
(a watcher releases them when the printer is ready). Force-print:
`POST /jobs/{id}/release` (single) · `POST /jobs/release_all` (all).
`GET /jobs/{id}` returns one job (used by the live watcher).

### Virtual PDF printers
Printing to "Microsoft Print to PDF" is auto-routed to a direct PDF save
(status `saved`, `file` = full path) — no renderer, no Save-As dialog,
works with no physical printer installed.

## v3.4.7 — configurable hub port, strict LAN share, rule testing

### The hub port is configurable
`port` is a normal config key now (default **9235**). Change it in the
ONE UI → Settings → HUB PORT, with `python advprint.py port 9300`, or by
editing `config.json`. Validation: 1024–65535, and 631 / 5353 / 9100 are
refused (the hub's own IPP mirror, mDNS and RAW listener). The env
`ADVPRINT_PORT` still wins over config.json. The listener rebinds on the
next restart; `POST /config {"port": ...}` answers with `"restart": true`
and a note. If the port is busy at boot, hub.log prints every way to move
the hub to a free one.

### GET /lan/hits — strict LAN share hit list
Recorded while `lan_strict` is ON (config key, default false): every
distinct client IP that touches the hub, allowed or refused.
`{"ok":true,"strict":true,"allowed":["10.26.94.100"],"hits":[
 {"ip":"10.26.94.206","count":42,"first":"...","last":"...","allowed":true},
 {"ip":"10.26.94.77","count":3,"first":"...","last":"...","allowed":false}]}`
Newest first, capped at 128 addresses. Loopback is recorded as allowed.

### POST /lan/allow — one-click allow / remove
Body: `{"ip":"10.26.94.77"}` (or `{"ip":"10.26.94.0/24"}`,
`{"ip":"10.26.*"}`) appends to `allowed_ips` — if the list was `["*"]` it
is REPLACED, which locks the hub down to real entries (the response says
so). Body `{"ip":"...","remove":true}` takes the entry off again.
`127.0.0.1` is always allowed and refused as an argument.

### POST /lan/hits/clear
Forgets every recorded hit. `{"ok":true,"hits":[]}`.

### POST /rules/test + GET /rules/test?url=... — which rule would fire?
Evaluates `rules_mirror` with the SAME semantics as the browser extension
(glob / regex / contains, top to bottom, first match wins, `on`/`enabled`
respected, optional title/kind filters). Body:
`{"url":"https://www.htncr.org/lab/sample/203182","kind":"zpl"}`
(`kind` and `title` optional). Answer when a rule matches:
`{"ok":true,"matched":true,"total_rules":3,"rule":{"name":"Sample label
ZPL","pattern":"htncr\\.org/lab/sample/\\d+$","type":"regex","printer":
"Zebra GK420d","action":"raw","copies":1,"paper":""},"printer":"Zebra
GK420d","note":"rule matched - ..."}`; when none matches:
`{"ok":true,"matched":false,"printer":"OS default printer","note":
"no rule matched - ..."}`. Nothing is printed by this endpoint.
`rules_mirror` entries now keep their `type` field
(`"glob" | "regex" | "contains"`; default `glob`).
See `docs/PRINT-RULES-RECIPES.md` for the full URL recipes guide.
