#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ============================================================
#  AdvPrint Pro - Control Tool  (scriptable helper)
#  v3.2.6 - the interactive numbered menu is REMOVED (user request:
#  "AdvPrint Tool no need extra - it already exists in UI"). Running
#  the tool without arguments opens THE ONE UI console in the browser.
#  Everything the menu did lives in the console now; the one-shot
#  subcommands stay for scripts and repairs:
#    python tool.py start|stop|restart|status|testprint|history
#    python tool.py autorun on|off | livetest | diagnose | dashboard
#    python tool.py service-install|service-remove|service-status
#    python tool.py update-check | uninstall
#
#  Windows : the Start Menu shortcut opens THE ONE UI console.
#  Unix    : python3 tool.py   (after install-unix.sh / .deb)
# ============================================================

import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.request
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

IS_WIN = sys.platform == "win32"
# v2.6.6: CREATE_NO_WINDOW for every console child (tasklist / taskkill /
# powershell). The tool normally owns a console so children inherit it,
# but when the tool itself runs hidden (VBS / service context) an
# unflagged child would pop a black console window - the periodic
# "screen glitch" reported on Windows. Zero flashes now, everywhere.
HIDE = 0x08000000 if IS_WIN else 0


def _load_advprint():
    """Import the hub module (this folder ships next to advprint.py)."""
    import advprint
    return advprint


def _health():
    """(ok, info_dict) from the running hub, using the configured token."""
    ph = _load_advprint()
    url = "http://127.0.0.1:%d/health" % ph.CFG["port"]
    req = urllib.request.Request(url)
    try:
        with urllib.request.urlopen(req, timeout=3) as r:
            return True, json.loads(r.read().decode("utf-8", "replace"))
    except Exception:
        return False, None


def hub_running():
    ok, _ = _health()
    return ok


def _port_listening():
    """True when SOMETHING accepts TCP on our port (hub or not)."""
    ph = _load_advprint()
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1.0)
    try:
        return s.connect_ex(("127.0.0.1", ph.CFG["port"])) == 0
    finally:
        s.close()


def _tail(path, n=25):
    """Last n lines of a text file (hub.log), [] when unreadable."""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return [l.rstrip() for l in f.read().splitlines()[-n:]]
    except OSError:
        return []


def _win_process_alive(image):
    """Windows: is a process with this image name running?"""
    if not IS_WIN:
        return False
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq %s" % image],
                           capture_output=True, text=True, timeout=10,
                           creationflags=HIDE)
        return image.lower() in (r.stdout or "").lower()
    except Exception:
        return False


def _manual_command():
    """Copy/paste-ready manual start command with the REAL full path -
    'python advprint.py serve' from C:\\Users\\<name> can never work."""
    ph = _load_advprint()
    script = os.path.join(HERE, "advprint.py")
    if IS_WIN and os.path.isfile(sys.executable):
        return '"%s" "%s" serve' % (sys.executable, script)
    return 'python3 "%s" serve' % script


def _report_start_failure():
    """v2.6.1: when the hub did not answer, show WHY right here in the
    tool - log tail, process state, port owner, manual command."""
    ph = _load_advprint()
    logp = os.path.join(ph.CFG["data_dir"], "hub.log")
    print("")
    print("  --- start-up diagnosis ------------------------------------")
    if _port_listening():
        if hub_running():
            print("  Port %d      : the hub IS running and healthy." % ph.CFG["port"])
        else:
            print("  Port %d      : SOMETHING is listening but /health did"
                  " not answer yet - either the hub is still warming up"
                  " (run start again) or another program holds the"
                  " port." % ph.CFG["port"])
    else:
        print("  Port %d      : nothing is listening - the hub process is"
              " not serving." % ph.CFG["port"])
    if IS_WIN:
        alive = (_win_process_alive("AdvPrintPro.exe")
                 or _win_process_alive("pythonw.exe"))
        print("  Hub process : %s" %
              ("AdvPrintPro.exe is running (still starting? wait 10 s)"
               if alive else "NOT running - it exited or was blocked"))
        if not alive:
            print("                 (antivirus tools sometimes silently kill"
                  " a freshly downloaded exe - run 'python tool.py diagnose', it also"
                  " unblocks the folder)")
    tail = _tail(logp, 20)
    if tail:
        print("  hub.log (last lines):")
        for l in tail:
            print("    " + l)
    else:
        print("  hub.log     : not written yet - the hub died before it"
              " could log anything (blocked exe / missing file / AV).")
    print("  Manual start (copy/paste into cmd - full path, works from"
          " any folder):")
    print("    " + _manual_command())
    print("  Or run the one-shot fixer - 'python tool.py diagnose' - it finds and repairs the"
          " usual causes automatically.")
    print("  -----------------------------------------------------------")
    print("")


def start_hub():
    """Start the hub detached (returns True when the process spawned)."""
    if hub_running():
        print("AdvPrint Pro is ALREADY running (port in use).")
        return True
    ph = _load_advprint()
    script = os.path.join(HERE, "advprint.py")
    # v2.6.1 pre-flight: clear message instead of a silent death when
    # the install folder is incomplete (bad unzip / AV quarantine).
    if not os.path.isfile(script):
        print("ERROR: %s" % script)
        print("  ...is MISSING - your install folder is incomplete.")
        print("  Re-extract the FULL AdvPrint-Pro zip (keep the folder")
        print("  structure), or reinstall with the Setup exe.")
        return False
    if IS_WIN:
        exe = ph.launcher_exe()                    # AdvPrintPro.exe / pythonw
        if not os.path.isfile(exe):
            exe = sys.executable                   # bundled python.exe
            print("(note: AdvPrintPro.exe missing - starting with the"
                  " bundled python)")
        det = 0x00000008 | 0x00000200              # DETACHED | NEW_PROCESS_GROUP
        try:
            subprocess.Popen([exe, script, "serve"], cwd=HERE,
                             close_fds=True, creationflags=det)
        except Exception as e:
            print("Could not start the hub: %s" % e)
            print("If this is 'Permission denied' or 'Access is denied':")
            print("  Windows or your antivirus blocked the freshly downloaded"
                  " file.")
            print("  Run 'python tool.py diagnose' - it unblocks the folder"
                  " automatically (no admin needed).")
            return False
    else:
        try:
            subprocess.Popen(["nohup", sys.executable,
                              os.path.join(HERE, "advprint.py"), "serve"],
                             cwd=HERE,
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL,
                             start_new_session=True)
        except Exception as e:
            print("Could not start the hub: %s" % e)
            return False
    print("Starting AdvPrint Pro ...")
    # v2.6.3: poll up to 30 s and TELL THE DIFFERENCE between "nothing is
    # listening" and "the hub is up but /health is still warming". The
    # v2.6.2 report showed the hub listening (hub.log) while this tool
    # gave up after 20 s because /health ran slow PowerShell scans on the
    # request path - that is fixed hub-side; the extra headroom and the
    # explicit "port is up" beat make any remaining slow case visible
    # instead of a bare failure.
    warmed = False
    for i in range(60):
        time.sleep(0.5)
        if hub_running():
            ok, info = _health()
            print("Started: v%s on http://127.0.0.1:%s"
                  % (info.get("version", "?"), info.get("port", ph.CFG["port"])))
            print("Tray icon 'AdvPrint Pro' should now sit next to the clock"
                  " (may hide under the ^ arrow).")
            return True
        if not warmed and _port_listening():
            warmed = True
            print("  ... port is up - the hub process is starting, waiting"
                  " for its health endpoint (up to 30 s)")
        if i in (9, 19, 29, 39, 49):
            print("  ... still waiting (%d s) - first start can be slow"
                  % ((i + 1) // 2))
    print("The hub did not answer within 30 seconds.")
    _report_start_failure()
    return False


def stop_hub():
    ph = _load_advprint()
    if not hub_running():
        print("AdvPrint Pro is not running.")
        return True
    if IS_WIN:
        # kill by image name (ours is renamed pythonw -> AdvPrintPro.exe;
        # pre-2.6 installs ran as PrintHubPro.exe - kill both)
        r = subprocess.run(["taskkill", "/F", "/IM", "AdvPrintPro.exe"],
                           capture_output=True, text=True, creationflags=HIDE)
        if r.returncode != 0:
            subprocess.run(["taskkill", "/F", "/IM", "PrintHubPro.exe"],
                           capture_output=True, text=True, creationflags=HIDE)
        if r.returncode != 0:
            # fall back: kill whoever listens on our port
            subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "Get-NetTCPConnection -LocalPort %d -State Listen "
                 "-ErrorAction SilentlyContinue | Select-Object -ExpandProperty "
                 "OwningProcess | ForEach-Object { Stop-Process -Id $_ -Force "
                 "-ErrorAction SilentlyContinue }" % ph.CFG["port"]],
                capture_output=True, text=True, creationflags=HIDE)
    else:
        subprocess.run(["pkill", "-f", "advprint.py serve"],
                       capture_output=True, text=True)
    time.sleep(1.0)
    print("Stopped." if not hub_running() else "Still running? Check the tray icon.")
    return not hub_running()


def restart_hub():
    """v2.8: restart the RUNNING hub without killing it hard.
    The hub relaunches ITSELF as a new process (POST /restart) - settings
    are re-read, the port is re-bound, nothing is lost. When the hub is
    not running this simply starts it."""
    ph = _load_advprint()
    if not hub_running():
        print("AdvPrint Pro is not running - starting it instead...")
        return start_hub()
    old_ver = (_health()[1] or {}).get("version", "?")
    print("Restarting AdvPrint Pro v%s ..." % old_ver)
    url = "http://127.0.0.1:%d/restart" % ph.CFG["port"]
    req = urllib.request.Request(
        url, method="POST",
        data=b"{}",
        headers={"Content-Type": "application/json",
                 "X-AdvPrint-Token": ph.CFG["token"]})
    try:
        with urllib.request.urlopen(req, timeout=6) as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
        if not d.get("ok"):
            print("  Hub answered: %s" % d.get("error", "?"))
    except Exception as e:
        print("  Restart request failed (%s) - hard stop + start instead." % e)
        stop_hub()
        return start_hub()
    print("  Stop request accepted - waiting for the hub to come back...")
    deadline = time.time() + 45
    while time.time() < deadline:
        time.sleep(1.0)
        ok, info = _health()
        if ok:
            print("  [OK] AdvPrint Pro v%s is back on http://127.0.0.1:%d"
                  % (info.get("version", "?"), ph.CFG["port"]))
            return True
    print("  The hub did not answer within 45 s - check the tray icon or"
          " 'python tool.py diagnose'.")
    return False
    ph = _load_advprint()
    ok, info = _health()
    print("-" * 62)
    print(" AdvPrint Pro v%s  (tool v%s)" % (ph.VERSION, ph.VERSION))
    print("-" * 62)
    if ok:
        print("  Hub          : RUNNING on http://127.0.0.1:%d" % ph.CFG["port"])
        print("  Queue        : %s, %s pending, %s jobs today"
              % ("PAUSED" if info.get("paused") else "running",
                 info.get("pending", 0), info.get("jobs_today", 0)))
        print("  Auto-run     : %s"
              % ("ON" if info.get("autostart") else "off"))
        try:
            with urllib.request.urlopen(
                    "http://127.0.0.1:%d/dropzone" % ph.CFG["port"],
                    timeout=3) as r:
                dzd = json.loads(r.read().decode("utf-8", "replace"))
            if dzd.get("ok"):
                print("  DropZone     : %s (%d waiting, %d done)"
                      % ("ON" if dzd.get("enabled") else "off",
                         dzd.get("waiting", 0), dzd.get("done", 0)))
        except Exception:
            pass
        svc = info.get("service")
        if svc is not None:
            print("  Windows svc  : %s" % svc.get("state", "?"))
    else:
        print("  Hub          : NOT RUNNING")
        print("  Auto-run     : %s"
              % ("ON" if ph.autostart_enabled() else "off"))
    if IS_WIN:
        print("  Data folder  : %s" % ph.CFG["data_dir"])
        print("  Install folder: %s" % HERE)
        print("  SumatraPDF   : %s"
              % ("found" if info and info.get("sumatra_found")
                 else ("not found (PDF printing needs it)" if ok else "n/a")))
    print("-" * 62)
    return ok


def set_autorun(enable):
    ph = _load_advprint()
    state = ph.autostart_set(bool(enable))
    print("Start at Windows logon: %s" % ("ON" if state else "OFF"))
    if IS_WIN:
        print("  (Task Manager > Startup apps -> 'AdvPrint Pro')")


def test_page():
    if not hub_running():
        print("Start the hub first.")
        return
    ph = _load_advprint()
    url = "http://127.0.0.1:%d/testprint?kind=a4" % ph.CFG["port"]
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        print("Test page queued (job #%s) - watch the printer." % data.get("job_id"))
    except Exception as e:
        print("Test page failed: %s" % e)


def show_history(limit=15):
    ph = _load_advprint()
    ph.db_init()
    rows = ph.db_list(limit)
    if not rows:
        print("No print jobs yet.")
        return
    print(" %-4s %-19s %-9s %-24s %s" % ("ID", "TIME", "STATUS", "PRINTER", "TITLE"))
    print("-" * 78)
    for r in rows:
        print(" %-4s %-19s %-9s %-24s %s"
              % (r["id"], (r["created_at"] or "")[0:19], r["status"],
                 (r["printer"] or "-")[:24], (r["title"] or "-")[:34]))


def service(action):
    ph = _load_advprint()
    if action == "status":
        ph.cmd_service("status")
        return
    if not IS_WIN:
        print("Windows services are Windows-only. On Linux/macOS the .deb /"
              " install-unix.sh sets up systemd.")
        return
    print("This will %s the 'AdvPrint' Windows service." %
          ("INSTALL" if action == "install" else "REMOVE"))
    print("A Windows UAC prompt will appear - click Yes to approve.")
    a = input("Continue? [y/N]: ").strip().lower()
    if a in ("y", "yes"):
        ph.cmd_service(action)
    else:
        print("Canceled.")


def update_check():
    ph = _load_advprint()
    ph.cmd_update_check()


def livetest(do_print=False):
    """v2.6 LIVE TEST: full A-to-Z self-check (console Tools menu / CLI)."""
    ph = _load_advprint()
    ph.db_init()
    ph.init_config()
    print("-" * 62)
    print(" AdvPrint Pro LIVE TEST - full A-to-Z check")
    print("-" * 62)
    res = ph.run_livetest(do_print=do_print)
    for st in res["steps"]:
        print("  [%s] %-38s %s" % ("OK" if st["pass"] else "!!",
                                   st["name"], st["info"]))
    print("")
    print("  %s" % ("ALL CHECKS PASSED - AdvPrint Pro is ready for production."
                   if res["all_ok"] else
                   "Fix the [!!] items above, then run the live test again."))
    if do_print:
        print("  (a REAL test page was queued - watch it on the dashboard)")
    return 0 if res["all_ok"] else 1


def diagnose_and_fix():
    """v2.6.1: find and REPAIR the usual 'hub offline' causes
    without any console knowledge:
      1. install-folder pre-flight (missing files -> exact name shown)
      2. unblock the folder (Windows Mark-of-the-Web from downloaded zips)
      3. free the port from zombies (old hub instances)
      4. VISIBLE console start test - the hub's own output shows any
         remaining error in plain text, right here in the tool
      5. hub.log tail + copy/paste manual start command
    Nothing here needs admin rights.
    """
    ph = _load_advprint()
    print("-" * 62)
    print(" Diagnose & fix - why does the hub not start?")
    print("-" * 62)
    script = os.path.join(HERE, "advprint.py")

    # ---- 1. pre-flight ------------------------------------------------
    print("\n[1/5] Install folder check")
    need = ["advprint.py", "tool.py", "tray_windows.py", "service_main.py"]
    missing = [f for f in need if not os.path.isfile(os.path.join(HERE, f))]
    print("  folder      : %s" % HERE)
    print("  hub script  : %s" % ("OK" if os.path.isfile(script) else "MISSING"))
    if missing:
        print("  also missing: %s" % ", ".join(missing))
        print("  FIX: re-extract the FULL zip (keep folder structure) or"
              " reinstall the Setup exe - files ARE missing, nothing to"
              " repair here.")
        return
    if IS_WIN:
        exe = ph.launcher_exe()
        print("  launcher    : %s (%s)" %
              (exe, "OK" if os.path.isfile(exe) else "missing - tool will"
               " fall back to the bundled python"))
        # v2.6.5: show the PDF engine detection result up front - the
        # per-user SumatraPDF (C:\Users\<name>\AppData\Local\...) is the
        # most common "why can I not print PDFs" answer.
        try:
            sm = ph.find_sumatra()
            print("  SumatraPDF  : %s" % (sm if sm else
                  "not found - install it or set it in the dashboard"
                  " Settings"))
        except Exception:
            print("  SumatraPDF  : lookup failed (non-critical)")

    # ---- 2. unblock (Mark-of-the-Web) ----------------------------------
    if IS_WIN:
        print("\n[2/5] Unblock the folder (Windows may block downloaded"
              " files)")
        # v2.6.5: unblock EVERY location the hub can execute from -
        # the install folder (Setup: Program Files, portable: the zip
        # folder) AND the per-user copies a previous install may have
        # left behind (%LOCALAPPDATA%\AdvPrintPro) AND the per-user
        # SumatraPDF.exe (%LOCALAPPDATA%\SumatraPDF / ...\Programs\
        # SumatraPDF). Blocked exes there produced "print jobs stuck
        # queued" with no visible error - now they are repaired too.
        root = os.path.dirname(HERE.rstrip(os.sep)) or HERE
        roots = {root,
                 os.path.join(os.environ.get("LOCALAPPDATA", ""),
                              "AdvPrintPro"),
                 os.path.join(os.environ.get("LOCALAPPDATA", ""),
                              "SumatraPDF"),
                 os.path.join(os.environ.get("LOCALAPPDATA", ""),
                              "Programs", "SumatraPDF")}
        roots.discard("")
        roots = [r for r in sorted(roots) if os.path.isdir(r)]
        for p in roots:
            ps = ("$n=0; Get-ChildItem -LiteralPath '{p}' -Recurse -File"
                  " -ErrorAction"
                  " SilentlyContinue | ForEach-Object {{ try {{ Unblock-File"
                  " -LiteralPath $_.FullName -ErrorAction Stop; $n++ }}"
                  " catch {{}} }};"
                  " Write-Output ('unblocked ' + $n + ' files')").format(p=p)
            try:
                r = subprocess.run(
                    ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                     "-Command", ps],
                    creationflags=0x08000000, capture_output=True, text=True,
                    timeout=60)
                out = (r.stdout or "").strip().splitlines()
                print("  %s (folder: %s)" % (out[-1] if out else "done", p))
            except Exception as e:
                print("  skipped (%s) - not critical" % e)
    else:
        print("\n[2/5] Unblock: not needed on this OS")

    # ---- 3. port + zombies ----------------------------------------------
    print("\n[3/5] Port %d" % ph.CFG["port"])
    if _port_listening():
        if hub_running():
            print("  the hub is ALREADY running and healthy - nothing to"
                  " fix. Close and reopen the console (python tool.py dashboard).")
            return
        print("  SOMETHING (not the hub) is listening on the port.")
        a = input("  Kill whatever holds port %d now? [Y/n]: "
                  % ph.CFG["port"]).strip().lower()
        if a not in ("n", "no"):
            if IS_WIN:
                subprocess.run(
                    ["powershell", "-NoProfile", "-Command",
                     "Get-NetTCPConnection -LocalPort %d -State Listen "
                     "-ErrorAction SilentlyContinue | Select-Object"
                     " -ExpandProperty OwningProcess | ForEach-Object {"
                     " Stop-Process -Id $_ -Force -ErrorAction"
                     " SilentlyContinue }" % ph.CFG["port"]],
                    capture_output=True, text=True, timeout=30,
                    creationflags=HIDE)
            else:
                subprocess.run(["fuser", "-k", "%d/tcp" % ph.CFG["port"]],
                               capture_output=True, text=True)
            time.sleep(1.0)
            print("  port now free" if not _port_listening()
                  else "  still busy - reboot clears stubborn holders")
    else:
        print("  free - good")

    # ---- 4. visible console start test ----------------------------------
    print("\n[4/5] Start test (the hub runs in plain view - any error"
          " shows here)")
    if IS_WIN:
        outp = os.path.join(tempfile.gettempdir(), "advprint-start-test.log")
        try:
            os.remove(outp)
        except OSError:
            pass
        with open(outp, "w", encoding="utf-8") as tf:
            proc = subprocess.Popen(
                [sys.executable, script, "serve"], cwd=HERE,
                stdout=tf, stderr=subprocess.STDOUT,
                creationflags=HIDE)  # v2.6.6: output goes to the file -
                                     # never allocate an extra console
        came_up = False
        for _ in range(20):
            time.sleep(0.5)
            if hub_running():
                came_up = True
                break
        if came_up:
            ok, info = _health()
            print("  THE HUB STARTS FINE when run in the open:")
            print("    v%s on http://127.0.0.1:%s (token guard OK)"
                  % (info.get("version", "?"), info.get("port", "?")))
            print("  So the hub works - the blocked one was only the hidden"
                  " background start (antivirus).")
            b = input("  Keep THIS running and close the tool? [Y/n]: ")
            if b.strip().lower() not in ("n", "no"):
                print("  AdvPrint Pro stays running. For the normal hidden"
                      " start (recommended, with tray icon) close the tool"
                      " and run 'python tool.py start' next time.")
                return
            proc.terminate()
            time.sleep(1.0)
            print("  test instance stopped - run 'python tool.py start' to start hidden")
            return
        proc.terminate()
        time.sleep(1.0)
        print("  the hub FAILED to start - its own output:")
        for l in _tail(outp, 30):
            print("    " + l)
    else:
        print("  (unix: run 'python3 %s serve' in a terminal to see"
              " the error directly)" % script)

    # ---- 5. log tail + manual command -----------------------------------
    print("\n[5/5] hub.log (last 20 lines) + manual start")
    tail = _tail(os.path.join(ph.CFG["data_dir"], "hub.log"), 20)
    if tail:
        for l in tail:
            print("    " + l)
    else:
        print("    (hub.log is empty or missing)")
    print("\n  Manual start (copy/paste into cmd/terminal):")
    print("    " + _manual_command())
    print("  If the output above mentions permissions/antivirus: add the")
    print("  AdvPrint folder to your AV's exclusions, then run 'python tool.py start'.")


def uninstall():
    """Full removal: stop hub, remove autostart, offer service removal."""
    ph = _load_advprint()
    print("UNINSTALL AdvPrint Pro")
    print("  1) stop the hub now")
    print("  2) remove 'start at logon' auto-run")
    a = input("Continue? [y/N]: ").strip().lower()
    if a not in ("y", "yes"):
        print("Canceled.")
        return
    stop_hub()
    try:
        set_autorun(False)
    except Exception:
        pass
    if IS_WIN:
        st = ph.service_state()
        if st and st.get("installed"):
            b = input("Windows service found - remove it too? [Y/n]: ").strip().lower()
            if b in ("", "y", "yes"):
                service("remove")
    print("")
    print("The hub and its auto-run are removed.")
    if IS_WIN:
        print("To remove the program files completely, use:")
        print("  Windows Settings > Apps > AdvPrint Pro > Uninstall")
        print("(or Start Menu > AdvPrint Pro > Uninstall AdvPrint Pro)")
    print("Your print history stays in: %s" % ph.CFG["data_dir"])


# ------------------------------------------------------------
# v3.2.6: the interactive numbered menu is GONE (user request -
# "AdvPrint Tool no need extra, it already exists in UI"). The console
# IS the menu now; running this file opens it.
# ------------------------------------------------------------
def open_console():
    """Open THE ONE UI console in the default browser (the hub must be
    running - the tray icon or 'python tool.py start' starts it)."""
    ph = _load_advprint()
    import urllib.parse
    ok, info = _health()
    if not ok:
        print("The hub is not running yet - starting it ...")
        start_hub()
    webbrowser.open("http://127.0.0.1:%d/ui?token=%s" % (
        ph.CFG["port"], urllib.parse.quote(str(ph.CFG.get("token") or ""))))
    print("Opened THE ONE UI console: http://127.0.0.1:%d/ui" % ph.CFG["port"])


def usage():
    print("""AdvPrint Pro Tool - one-shot commands (v3.2.6: the menu
lives in THE ONE UI console - running this file with no arguments
opens it):
  (no command)  open THE ONE UI console in the browser
  status        show status
  start|stop    start / stop the hub
  restart       restart the running hub (clean relaunch, v2.8)
  testprint     print a test page
  history [n]   show recent jobs
  autorun on|off   start-at-logon on/off
  livetest [print] full A-to-Z live self-test ("print" = real test page)
  diagnose        find and fix why the hub will not start
  dashboard       open the console with the current token
  service-install | service-remove | service-status
  update-check  check GitHub for updates
  uninstall     stop + de-register (program files via Apps settings)
  help          this text""")


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else ""
    if not cmd:
        # v3.2.6: no interactive menu any more - open the console UI.
        open_console()
        return
    if cmd == "status":
        show_status()
    elif cmd == "start":
        start_hub()
    elif cmd == "stop":
        stop_hub()
    elif cmd == "restart":
        restart_hub()
    elif cmd == "testprint":
        test_page()
    elif cmd == "history":
        show_history(int(args[1]) if len(args) > 1 else 15)
    elif cmd == "autorun" and len(args) > 1:
        set_autorun(args[1].lower() in ("on", "1", "true", "yes"))
    elif cmd == "service-install":
        service("install")
    elif cmd == "service-remove":
        service("remove")
    elif cmd == "service-status":
        service("status")
    elif cmd == "update-check":
        update_check()
    elif cmd == "uninstall":
        uninstall()
    elif cmd == "livetest":
        sys.exit(livetest(do_print=(len(args) > 1 and args[1] == "print")))
    elif cmd == "diagnose":
        diagnose_and_fix()
    elif cmd == "dashboard":
        open_console()
    elif cmd in ("help", "--help", "-h"):
        usage()
    else:
        print("Unknown command: %s\n" % cmd)
        usage()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nBye!")
